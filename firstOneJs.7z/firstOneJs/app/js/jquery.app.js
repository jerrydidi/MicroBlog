(function($){
	 $.extend({app:{
         index_url:"",
	     users:new Array()

     }});
})(jQuery);